# tinygrad directory layout

This explains the flow of a big graph down to programs.

Directories are listed in order of how they are processed.

---

## tinygrad/schedule

Group UOps into kernels.

::: tinygrad.schedule.rangeify.get_kernel_graph
    options:
        members: false
        show_labels: false
        show_source: false

---

## tinygrad/codegen/opt

Transforms the ast into an optimized ast. This is where BEAM search and heuristics live.

---

## tinygrad/codegen

Transform the optimized ast into a linearized and rendered program.

::: tinygrad.codegen.to_program
    options:
        members: false
        show_labels: false
        show_source: false

---

## tinygrad/renderer

Transform the linearized list of UOps into a program, represented as a string.

::: tinygrad.renderer.Renderer
    options:
        members:
            - render
        show_labels: false
        show_source: false

---

## tinygrad/engine

Abstracted high level interface to the runtimes.

::: tinygrad.engine.realize.to_program
    options:
        members: false
        show_labels: false
        show_source: false
